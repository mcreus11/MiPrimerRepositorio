package com.mx.Book.Controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mx.Book.Entity.Book;

@RestController
@RequestMapping("/api/books")
public class BookController {

	private static final List<Book> books = new ArrayList<>();

    static {
        books.add(new Book(1, "El principito", "Antoine de Saint-Exupéry", 15.5));
        books.add(new Book(2, "Cien años de soledad", "Gabriel García Márquez", 25.0));
    }

    // GET /api/books
    @GetMapping
    public List<Book> getAllBooks() {
        return books;
    }

    // GET /api/books/{id}
    @GetMapping("/{id}")
    public ResponseEntity<?> getBookById(@PathVariable int id) {
        return books.stream()
                .filter(book -> book.getId() == id)
                .findFirst()
                .<ResponseEntity<?>>map(ResponseEntity::ok).orElseGet(() 
                		-> ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(Map.of("error", "Libro no encontrado")));
    }

}
